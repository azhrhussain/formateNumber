import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'challange-app',
  templateUrl: './challange.component.html',
  styleUrls: ['./challange.component.css']
})
export class ChallangeComponent  {
  output:any = '';
  constructor() { }

  number(event:any){
    let inputVal = event.target.value;
    //for lesser input
    if(inputVal < 1000){
      this.output = inputVal;
    }
    //for K
    else if(inputVal >= 1000 && inputVal < 100000){
      this.output = (inputVal/1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    //for M    
    else if(inputVal >= 100000 && inputVal < 1000000000){
      this.output = (inputVal/1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    
    else if(inputVal > 1000000000){
      this.output = "Beyond Scope";
    }

  }

}
