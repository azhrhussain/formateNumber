import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { PanelComponent } from './panel/panel.component';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { ChallangeComponent } from './challange/challange.component';
import { ShortNumCustomPipe } from './short-num-custom.pipe';


@NgModule({
  declarations: [
    AppComponent,
    PanelComponent,
    SignupFormComponent,
    ChallangeComponent,
    ChallangeComponent,
    ShortNumCustomPipe
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
