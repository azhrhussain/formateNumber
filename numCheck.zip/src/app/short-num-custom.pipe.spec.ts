import { ShortNumCustomPipe } from './short-num-custom.pipe';

describe('ShortNumCustomPipe', () => {
  it('create an instance', () => {
    const pipe = new ShortNumCustomPipe();
    expect(pipe).toBeTruthy();
  });
});
