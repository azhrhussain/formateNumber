import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'shortNumCustom'
})
export class ShortNumCustomPipe implements PipeTransform {

  transform(value: any): any {
  
        // lesser value
      if(value <1000){
        return value ;
      }
      // for K
      else if(value >= 1000 && value < 100000){
        return (value/1000).toFixed(1).replace(/\.0$/, '') + 'K';
      }
      // for M
      else if(value >= 100000 && value < 1000000000){
        return (value/1000).toFixed(1).replace(/\.0$/, '') + 'M';
      }
      else if(value > 1000000000){
        return "Beyond Scope";
      }
  }
}


